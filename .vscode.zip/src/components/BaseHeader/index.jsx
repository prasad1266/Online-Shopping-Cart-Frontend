import React from 'react';
import "./BaseHeader.css"

const BaseHeader = (props) => {
    return (
        <div className='base-header-root'>
            <h4>OroSoft Shopping Cart</h4>
        </div>
    );
}

export default BaseHeader;